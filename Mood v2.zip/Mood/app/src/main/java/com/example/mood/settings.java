package com.example.mood;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class settings extends AppCompatActivity {

    private Button btnPrevious;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        btnPrevious = findViewById(R.id.homeBtn);
        btnPrevious.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                moveToActivityOne();
            }
        });
    }
    private void moveToActivityOne(){
        Intent intent = new Intent(settings.this, MainActivity.class );
        startActivity(intent);
    }
}
